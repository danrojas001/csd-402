//Dan Rojas
//25 Jan 26
//mod 2.2

import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class RockPaperScissors {
    public static void main(String[] args) {

        //computer picks its choice
        Random rand = new Random();
        int computerInt = rand.nextInt(3) + 1;
        String computerChoice = switch (computerInt) {
            case 1 -> "Rock";
            case 2 -> "Paper";
            case 3 -> "Scissors";
            default -> null;
        };


        //player picks their choice
        Scanner sc = new Scanner(System.in);
        System.out.println("""
                Let's play Rock Paper Scissors!
                1 = Rock
                2 = Paper
                3 = Scissors
                Please input 1, 2, or 3:""");
        int playerInt = userInputvalidation(sc);
        sc.close();
        String playerChoice = switch (playerInt) {
            case 1 -> "Rock";
            case 2 -> "Paper";
            case 3 -> "Scissors";
            default -> null;
        };


        //comparison is made, winner declared
        if (Objects.equals(playerChoice, computerChoice)) {
            System.out.println("You and I both selected " + playerChoice + ". It's a tie!");
        } else if ((Objects.equals(playerChoice, "Rock") && computerChoice.equals("Scissors")) ||
                (Objects.equals(playerChoice, "Paper") && computerChoice.equals("Rock")) ||
                (Objects.equals(playerChoice, "Scissors") && computerChoice.equals("Paper"))) {
            System.out.println("You picked " + playerChoice + ". I picked " + computerChoice + ". You win!");
        } else {
            System.out.println("You picked " + playerChoice + ". I picked " + computerChoice + ". I win!");
        }
    }

    /**
     *
     * @param sc scanner passed in to do validation
     */
    public static int userInputvalidation(Scanner sc) {
        int userChoice;

        while (true) {
            if (sc.hasNextInt()) {
                userChoice = sc.nextInt();
                if (userChoice >= 1 && userChoice <= 3) {
                    return userChoice;
                } else {
                    System.out.println("Invalid: input must be integer between 1 and 3");
                }
            } else {
                System.out.println("Invalid: input must be an integer");
                sc.next();
            }
        }
    }
}
